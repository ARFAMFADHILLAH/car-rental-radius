// fiveserver.config.js
module.exports = {
  php: "C:\\laragon\\bin\\php\\php-8.3.28-Win32-vs16-x64\\php.exe"
};
